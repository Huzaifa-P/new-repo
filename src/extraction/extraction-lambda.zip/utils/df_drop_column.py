def df_drop_column(df, tables_list):
    return df.drop(columns=tables_list)