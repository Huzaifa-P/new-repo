def rename_word_in_folder_name(word, target_word, replacement_word):
    return word.replace(target_word, replacement_word)