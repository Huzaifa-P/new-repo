import pandas as pd


def append_dates_to_df(target_df, target_df_column, input_df,  date_columns):
    for date_column in date_columns:
        date = pd.to_datetime(input_df[date_column]).dt.date
        target_df = pd.concat([target_df, pd.DataFrame(
            {target_df_column: date})], ignore_index=True)
    return target_df
