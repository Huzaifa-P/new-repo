def df_rename_column(df, rename_dict):
    df.rename(columns=rename_dict, inplace=True)